package BJack;
public interface HitStrategy {
    boolean shouldHit(AbstractPlayer abstractPlayer);
}
